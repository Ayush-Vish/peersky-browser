import { evalSnippets as snippets, filterCompactRules } from '../npm/@duckduckgo/autoconsent/dist/autoconsent.esm.js';
import compactRules from '../npm/@duckduckgo/autoconsent/rules/compact-rules.json.js';
import { ACTION_DISABLE_AUTOCONSENT } from '../npm/@ghostery/config/dist/esm/actions.js';
import Options, { getPausedDetails } from '../store/options.js';
import Config from '../store/config.js';
import Resources from '../store/resources.js';
import { parseWithCache } from '../utils/request.js';
import store from '../npm/hybrids/src/store.js';

async function initialize(msg, sender) {
  const [options, config] = await Promise.all([
    store.resolve(Options),
    store.resolve(Config)
  ]);
  if (options.terms && options.blockAnnoyances) {
    const { tab, frameId } = sender;
    const senderUrl = sender.url || `${sender.origin}/`;
    const hostname = senderUrl ? parseWithCache(senderUrl).hostname : "";
    if (getPausedDetails(options, hostname) || config.hasAction(hostname, ACTION_DISABLE_AUTOCONSENT)) {
      return;
    }
    const compact = filterCompactRules(compactRules, {
      url: senderUrl,
      mainFrame: frameId === 0
    });
    try {
      chrome.tabs.sendMessage(
        tab.id,
        {
          action: "autoconsent",
          type: "initResp",
          rules: { compact },
          config: {
            autoAction: options.autoconsent.autoAction,
            enableCosmeticRules: false,
            enableFilterList: false
          }
        },
        { frameId }
      );
    } catch {
    }
  }
}
async function evalCode(snippetId, id, tabId, frameId) {
  const [result] = await chrome.scripting.executeScript({
    target: {
      tabId,
      frameIds: [frameId]
    },
    world: chrome.scripting.ExecutionWorld?.MAIN ?? ("MAIN"),
    func: snippets[snippetId]
  });
  await chrome.tabs.sendMessage(
    tabId,
    {
      action: "autoconsent",
      id,
      type: "evalResp",
      result: result.result
    },
    {
      frameId
    }
  );
}
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action !== "autoconsent") return;
  if (!sender.tab) return;
  const frameId = sender.frameId;
  switch (msg.type) {
    case "init":
      return initialize(msg, sender);
    case "eval":
      return evalCode(msg.snippetId, msg.id, sender.tab.id, frameId);
    case "optInResult":
    case "optOutResult": {
      if (msg.result === true) {
        const { domain } = parseWithCache(sender.url);
        if (domain) {
          store.set(Resources, { autoconsent: { [domain]: Date.now() } });
        }
      }
      break;
    }
  }
});
