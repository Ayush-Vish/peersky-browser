import __vite_glob_0_0 from './components/dialog.js';
import __vite_glob_0_1 from './components/error-card.js';
import __vite_glob_0_2 from './components/feature.js';
import __vite_glob_0_3 from './components/pin-it.js';
import __vite_glob_0_4 from './components/step.js';
import __vite_glob_0_5 from './views/addon-health.js';
import Main from './views/main.js';
import Modes from './views/modes.js';
import __vite_glob_0_8 from './views/performance.js';
import __vite_glob_0_9 from './views/privacy.js';
import __vite_glob_0_10 from './views/skip.js';
import Success from './views/success.js';
import __vite_glob_0_12 from './views/web-trackers.js';
import define from '../../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/dialog.js": __vite_glob_0_0,"./components/error-card.js": __vite_glob_0_1,"./components/feature.js": __vite_glob_0_2,"./components/pin-it.js": __vite_glob_0_3,"./components/step.js": __vite_glob_0_4,"./views/addon-health.js": __vite_glob_0_5,"./views/main.js": Main,"./views/modes.js": Modes,"./views/performance.js": __vite_glob_0_8,"./views/privacy.js": __vite_glob_0_9,"./views/skip.js": __vite_glob_0_10,"./views/success.js": Success,"./views/web-trackers.js": __vite_glob_0_12


}),
  { prefix: 'onboarding', root: 'components' },
);
