import Options, { MODE_DEFAULT, MODE_ZAP } from '../../../store/options.js';
import { getBrowser, isMobile } from '../../../utils/browser-info.js';
import successDefaultImage from '../assets/success-default.js';
import successZapImage from '../assets/success-zap.js';
import pinExtensionChrome from '../assets/pin-extension-chrome.js';
import pinExtensionEdge from '../assets/pin-extension-edge.js';
import pinExtensionOpera from '../assets/pin-extension-opera.js';
import store from '../../../npm/hybrids/src/store.js';
import { html } from '../../../npm/hybrids/src/template/index.js';

let screenshotURL = "";
let type = "";
{
  const { name } = getBrowser();
  if (name === "chrome" || name === "yandex" || name === "oculus") {
    screenshotURL = pinExtensionChrome;
    type = "chrome";
  } else if (name === "edge" && !isMobile()) {
    screenshotURL = pinExtensionEdge;
    type = "edge";
  } else if (name === "opera") {
    screenshotURL = pinExtensionOpera;
    type = "opera";
  } else if (name === "brave") {
    screenshotURL = pinExtensionChrome;
    type = "brave";
  }
}
const Success = {
  options: store(Options),
  render: {
    connect: () => {
      chrome.runtime.sendMessage({
        action: "telemetry",
        event: "install_complete"
      });
    },
    value: ({ options }) => html`
      <template layout="column gap:2 width:::375px">
        <ui-card data-qa="view:success">
          <section layout="block:center column gap:2">
            ${options.mode === MODE_DEFAULT && html`
              <div layout="row center">
                <img src="${successDefaultImage}" layout="size:20" />
              </div>
              <ui-text type="display-s">Setup Successful</ui-text>
              <ui-text>
                Ghostery is all set to stop trackers in their tracks and protect
                your privacy while browsing!
              </ui-text>
            `}
            ${options.mode === MODE_ZAP && html`
              <div layout="row center">
                <img src="${successZapImage}" layout="size:20" />
              </div>
              <ui-text type="display-s">Setup Successful</ui-text>
              <ui-text>
                You’re all set to zap ads away, one site at a time.
              </ui-text>
              <div layout="column gap:0.5">
                <ui-text><span>1.</span> Open a site</ui-text>
                <ui-text><span>2.</span> Zap ads in the Ghostery panel</ui-text>
                <ui-text
                  ><span>3.</span> Build your own ad-free internet</ui-text
                >
              </div>
            `}
          </section>
        </ui-card>
        ${screenshotURL && html`
          <ui-card>
            <section layout="column gap:2">
              <ui-text type="display-xs" layout="block:center">
                What’s next?
              </ui-text>
              <img
                src="${screenshotURL}"
                layout="width:::full"
                style="border-radius:8px; overflow:hidden;"
              />
              <div layout="row items:center gap">
                <ui-icon
                  name="extension-${type}"
                  layout="block inline size:3"
                  color="tertiary"
                ></ui-icon>
                <ui-text type="label-m">Pin Extension for easy access</ui-text>
              </div>
              <ui-text>
                Click the puzzle icon next to the search bar and pin Ghostery to
                your toolbar.
              </ui-text>
              ${options.mode === MODE_DEFAULT && html`
                <ui-text>
                  Ghostery will show how many trackers were blocked on a page.
                  Clicking on the Ghostery icon reveals more detailed
                  information.
                </ui-text>
              `}
              ${options.mode === MODE_ZAP && html`
                <ui-text>
                  Ghostery will show how many ad trackers are on a page.
                  Clicking on the Ghostery icon enables you to remove ads and
                  view more details.
                </ui-text>
              `}
            </section>
          </ui-card>
          <onboarding-pin-it browser="${type}"> Pin it here </onboarding-pin-it>
        `}
      </template>
    `
  }
};

export { Success as default };
